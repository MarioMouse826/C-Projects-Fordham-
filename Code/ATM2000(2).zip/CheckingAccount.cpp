//Implementation of the class CheckingAccount.
#include <iostream>
#include <cmath>
using namespace std;

// To Do: include necessary header files



// To Do: Please write comments and code to implement CheckingAccount here



